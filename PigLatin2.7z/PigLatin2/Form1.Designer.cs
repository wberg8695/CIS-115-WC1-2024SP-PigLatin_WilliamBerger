﻿namespace PigLatin2
{
    partial class PigLatin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            translateButton = new Button();
            inputLabel = new Label();
            outputLabel = new Label();
            inputBox = new TextBox();
            SuspendLayout();
            // 
            // translateButton
            // 
            translateButton.Location = new Point(110, 160);
            translateButton.Name = "translateButton";
            translateButton.Size = new Size(94, 29);
            translateButton.TabIndex = 0;
            translateButton.Text = "Translate";
            translateButton.UseVisualStyleBackColor = true;
            translateButton.Click += Button1_Click;
            // 
            // inputLabel
            // 
            inputLabel.AutoSize = true;
            inputLabel.Location = new Point(110, 80);
            inputLabel.Name = "inputLabel";
            inputLabel.Size = new Size(97, 20);
            inputLabel.TabIndex = 1;
            inputLabel.Text = "Enter A Word";
            // 
            // outputLabel
            // 
            outputLabel.BorderStyle = BorderStyle.Fixed3D;
            outputLabel.Location = new Point(250, 160);
            outputLabel.Name = "outputLabel";
            outputLabel.Size = new Size(125, 27);
            outputLabel.TabIndex = 2;
            // 
            // inputBox
            // 
            inputBox.Location = new Point(250, 80);
            inputBox.Name = "inputBox";
            inputBox.Size = new Size(125, 27);
            inputBox.TabIndex = 3;
            // 
            // PigLatin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(472, 253);
            Controls.Add(inputBox);
            Controls.Add(outputLabel);
            Controls.Add(inputLabel);
            Controls.Add(translateButton);
            Name = "PigLatin";
            Text = "PigLatin Translator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button translateButton;
        private Label inputLabel;
        private Label outputLabel;
        private TextBox inputBox;
    }
}
