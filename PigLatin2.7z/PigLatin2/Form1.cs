namespace PigLatin2
{
    public partial class PigLatin : Form
    {
        public PigLatin()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string input, step1, step2, output;
            input = inputBox.Text;
            step1 = input.Substring(1, input.Length - 1);
            step2 = input.Substring(0, 1) + "ay";
            output = (step1 + step2);
            outputLabel.Text = output;
        }
    }
}
